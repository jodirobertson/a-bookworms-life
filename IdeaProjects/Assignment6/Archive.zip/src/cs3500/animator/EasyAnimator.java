package cs3500.animator;

/**
 * TODO
 */
public final class EasyAnimator {

  /**
   * TODO
   *
   * @param args
   */
  public static void main(String[] args) {
    // FILL IN HERE
  }
}

