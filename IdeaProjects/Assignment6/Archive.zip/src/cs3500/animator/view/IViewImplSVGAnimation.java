package cs3500.animator.view;

/**
 * Represents an IView that produces an output of the composition in an SVG file format.
 */
public class IViewImplSVGAnimation implements IView {


  @Override
  public void play() {

  }
}
