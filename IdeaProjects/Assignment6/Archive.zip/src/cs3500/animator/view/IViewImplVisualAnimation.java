package cs3500.animator.view;

/**
 * Represents a class that outputs an IView using JavaSwing that creates visual animations.
 */
public class IViewImplVisualAnimation implements IView {


  @Override
  public void play() {

  }
}
